#include "strategic_level_frame.h"

#include "main.h"

#include <wx/dcbuffer.h>
#include <wx/choicdlg.h>
#include <wx/graphics.h>
#include <wx/stdpaths.h>
#include <wx/filename.h>

#include <filesystem>
#include <fstream>
#include <vector>
#include <algorithm>
#include <cctype>

wxBEGIN_EVENT_TABLE(StrategicLevelFrame, wxFrame)
    EVT_BUTTON(StrategicLevelFrame::ID_BTN_RESEARCH, StrategicLevelFrame::OnResearch)
    EVT_BUTTON(StrategicLevelFrame::ID_BTN_BUY,      StrategicLevelFrame::OnBuyUnits)
    EVT_BUTTON(StrategicLevelFrame::ID_BTN_ENDTURN,  StrategicLevelFrame::OnEndTurn)
    EVT_BUTTON(StrategicLevelFrame::ID_BTN_LAUNCH,   StrategicLevelFrame::OnLaunch)
wxEND_EVENT_TABLE()

static wxString fmt_int(const wxString& label, int v)
{
    return wxString::Format("%s %d", label, v);
}

static std::string trim(std::string s)
{
    auto notspace = [](unsigned char c){ return !std::isspace(c); };
    s.erase(s.begin(), std::find_if(s.begin(), s.end(), notspace));
    s.erase(std::find_if(s.rbegin(), s.rend(), notspace).base(), s.end());
    return s;
}

static std::string to_upper(std::string s)
{
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return (char)std::toupper(c); });
    return s;
}

static std::string to_lower(std::string s)
{
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return (char)std::tolower(c); });
    return s;
}

StrategicLevelFrame::StrategicLevelFrame(MainFrame* parent, const LevelData& level)
    : wxFrame(parent, wxID_ANY, "Strategic Level", wxDefaultPosition, wxSize(1100, 700)),
      m_main(parent),
      m_level(level)
{
    m_money = 0;
    m_research = 0;

    // init territory mission state from LevelData
    for(const auto& t : m_level.territories)
    {
        m_territoryCurrentMission[t.id] = t.mission;
        m_territoryLaunchCount[t.id] = 0;
    }

    BuildUI();
    TryLoadBackground();
    RefreshUI();
}


static void DrawGreenGrid(wxGraphicsContext* gc, const wxRect& rc, int spacing, const wxColour& line)
{
    gc->SetPen(wxPen(line, 1));
    for(int x = rc.x; x <= rc.GetRight(); x += spacing)
        gc->StrokeLine(x + 0.5, rc.y, x + 0.5, rc.GetBottom());
    for(int y = rc.y; y <= rc.GetBottom(); y += spacing)
        gc->StrokeLine(rc.x, y + 0.5, rc.GetRight(), y + 0.5);
}

bool StrategicLevelFrame::LoadToolbarAtlas(wxBitmap& outAtlas)
{
    // Try a few common locations:
    //  1) working dir: ./ikony.png
    //  2) alongside executable: <exe>/ikony.png
    //  3) alongside level DEF (if LevelData contains a source path later; not available here)
    std::vector<wxString> candidates;
    candidates.push_back("ikony.png");

    wxFileName exe(wxStandardPaths::Get().GetExecutablePath());
    candidates.push_back(exe.GetPathWithSep() + "ikony.png");

    for(const auto& p : candidates)
    {
        if(wxFileExists(p))
        {
            wxImage img;
            if(img.LoadFile(p))
            {
                outAtlas = wxBitmap(img);
                return outAtlas.IsOk();
            }
        }
    }
    return false;
}

void StrategicLevelFrame::SliceToolbarAtlas(const wxBitmap& atlas)
{
    // atlas is a vertical strip: 81x513 with 9 icons of 81x57 each (based on supplied file)
    if(!atlas.IsOk())
        return;

    wxImage img = atlas.ConvertToImage();
    const int w = img.GetWidth();
    const int h = img.GetHeight();
    const int iconCount = 9;
    const int iconH = h / iconCount;

    for(int i = 0; i < iconCount; ++i)
    {
        wxImage sub = img.GetSubImage(wxRect(0, i * iconH, w, iconH));
        // slight upscale for modern UI (keeps it crisp-ish; better later when you provide higher-res icons)
        sub.Rescale(w*2, iconH*2, wxIMAGE_QUALITY_BICUBIC);
        m_toolIcons[i] = wxBitmap(sub);
    }
}

void StrategicLevelFrame::BuildUI()
{

auto root = new wxPanel(this);
root->SetBackgroundStyle(wxBG_STYLE_PAINT);

// Root layout: [Main] [Side] [Toolbar]
auto rootSizer = new wxBoxSizer(wxHORIZONTAL);

// --- MAIN column (map + bottom log) ---
auto mainCol = new wxPanel(root);
mainCol->SetBackgroundColour(wxColour(12, 35, 12));
auto mainSizer = new wxBoxSizer(wxVERTICAL);

// Map panel (custom paint already used for background)
m_mapPanel = new wxPanel(mainCol);
m_mapPanel->SetBackgroundStyle(wxBG_STYLE_PAINT);
m_mapPanel->Bind(wxEVT_PAINT, &StrategicLevelFrame::OnMapPaint, this);

// Bottom log/info panel (smooth: no native bevels)
auto bottomPanel = new wxPanel(mainCol);
bottomPanel->SetBackgroundColour(wxColour(10, 28, 10));
auto bottomSizer = new wxBoxSizer(wxVERTICAL);

m_log = new wxTextCtrl(bottomPanel, wxID_ANY, "", wxDefaultPosition, wxDefaultSize,
                       wxTE_MULTILINE | wxTE_READONLY | wxBORDER_NONE);
m_log->SetBackgroundColour(wxColour(6, 18, 6));
m_log->SetForegroundColour(wxColour(190, 230, 190));
bottomSizer->Add(m_log, 1, wxEXPAND | wxALL, 10);
bottomPanel->SetSizer(bottomSizer);

mainSizer->Add(m_mapPanel, 62, wxEXPAND);
mainSizer->Add(bottomPanel, 38, wxEXPAND);
mainCol->SetSizer(mainSizer);

// --- SIDE panel (green grid + roster/actions) ---
auto side = new wxPanel(root);
side->SetBackgroundStyle(wxBG_STYLE_PAINT);
side->Bind(wxEVT_PAINT, [side, this](wxPaintEvent&){
    wxAutoBufferedPaintDC dc(side);
    dc.Clear();
    auto gc = wxGraphicsContext::Create(dc);
    if(!gc) return;

    wxRect rc = side->GetClientRect();
    // base green
    gc->SetBrush(wxBrush(wxColour(8, 40, 8)));
    gc->SetPen(*wxTRANSPARENT_PEN);
    gc->DrawRectangle(rc.x, rc.y, rc.width, rc.height);

    // grid overlay
    DrawGreenGrid(gc, rc.Deflate(8,8), 28, wxColour(18, 70, 18));

    delete gc;
});

auto sideSizer = new wxBoxSizer(wxVERTICAL);

// Mini top HUD (Money/Research/Turn)
auto hud = new wxPanel(side);
hud->SetBackgroundColour(wxColour(15, 55, 15));
auto hudSizer = new wxBoxSizer(wxVERTICAL);
m_lblMoney = new wxStaticText(hud, wxID_ANY, "Peníze 0");
m_lblResearch = new wxStaticText(hud, wxID_ANY, "Výzkum 0");
m_lblTurn = new wxStaticText(hud, wxID_ANY, "Kolo 1");
auto f = m_lblMoney->GetFont();
f.SetPointSize(f.GetPointSize() + 2);
f.SetWeight(wxFONTWEIGHT_BOLD);
m_lblMoney->SetFont(f);
m_lblResearch->SetFont(f);
m_lblTurn->SetFont(f);
m_lblMoney->SetForegroundColour(wxColour(80, 255, 80));
m_lblResearch->SetForegroundColour(wxColour(80, 255, 80));
m_lblTurn->SetForegroundColour(wxColour(80, 255, 80));
hudSizer->Add(m_lblMoney, 0, wxLEFT | wxRIGHT | wxTOP, 10);
hudSizer->Add(m_lblResearch, 0, wxLEFT | wxRIGHT | wxTOP, 10);
hudSizer->Add(m_lblTurn, 0, wxLEFT | wxRIGHT | wxTOP | wxBOTTOM, 10);
hud->SetSizer(hudSizer);

sideSizer->Add(hud, 0, wxEXPAND | wxALL, 8);

// "Special" line (text only for now; can become buttons later)
auto special = new wxStaticText(side, wxID_ANY, "Speciální\nVyber všechny\nOdznač všechny\n\nJednotky");
special->SetForegroundColour(wxColour(190, 230, 190));
sideSizer->Add(special, 0, wxLEFT | wxRIGHT | wxTOP, 14);

// Roster list (transparent-ish look via border none)
m_roster = new wxListCtrl(side, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxLC_REPORT | wxLC_SINGLE_SEL | wxBORDER_NONE);
m_roster->InsertColumn(0, "Jednotka");
m_roster->InsertColumn(1, "Počet");
m_roster->SetBackgroundColour(wxColour(6, 18, 6));
m_roster->SetTextColour(wxColour(190, 230, 190));
sideSizer->Add(m_roster, 1, wxEXPAND | wxALL, 10);

// bottom action buttons (Attack/Cancel) – keep your existing IDs
auto actionRow = new wxBoxSizer(wxHORIZONTAL);
m_btnLaunch = new wxButton(side, ID_BTN_LAUNCH, "Útok");
auto btnCancel = new wxButton(side, wxID_CANCEL, "Zrušit");
actionRow->Add(m_btnLaunch, 1, wxEXPAND | wxALL, 6);
actionRow->Add(btnCancel, 1, wxEXPAND | wxALL, 6);
sideSizer->Add(actionRow, 0, wxEXPAND | wxLEFT | wxRIGHT | wxBOTTOM, 8);

side->SetSizer(sideSizer);

// --- TOOLBAR (icons + End Turn) ---
auto toolbar = new wxPanel(root);
toolbar->SetBackgroundColour(wxColour(60, 60, 60));
auto tbSizer = new wxBoxSizer(wxVERTICAL);

// load and slice atlas
if(LoadToolbarAtlas(m_toolbarAtlas))
    SliceToolbarAtlas(m_toolbarAtlas);

for(int i = 0; i < 9; ++i)
{
    auto id = ID_TOOL_BASE + i;
    auto b = new wxBitmapButton(toolbar, id, m_toolIcons[i], wxDefaultPosition, wxDefaultSize, wxBORDER_NONE);
    b->SetBackgroundColour(wxColour(70,70,70));
    b->Bind(wxEVT_BUTTON, &StrategicLevelFrame::OnTool, this);
    m_toolBtns[i] = b;
    tbSizer->Add(b, 0, wxALIGN_CENTER | wxTOP, 10);
}

tbSizer->AddStretchSpacer(1);

m_btnEndTurn = new wxButton(toolbar, ID_BTN_ENDTURN, "Kolo");
tbSizer->Add(m_btnEndTurn, 0, wxEXPAND | wxALL, 12);

toolbar->SetSizer(tbSizer);

// Assemble root
rootSizer->Add(mainCol, 64, wxEXPAND);
rootSizer->Add(side,    25, wxEXPAND);
rootSizer->Add(toolbar, 11, wxEXPAND);
root->SetSizer(rootSizer);

// Init background
TryLoadBackground();

// Territory buttons overlay: keep for now, but place into mapPanel sizer so it overlays (you can remove later)
m_mapSizer = new wxBoxSizer(wxVERTICAL);
auto grid = new wxGridSizer(0, 4, 6, 6);
for(size_t i = 0; i < m_level.territories.size(); ++i)
{
    const auto& t = m_level.territories[i];
    auto id = ID_TERRITORY_BASE + (int)i;

    wxString label = wxString::Format("T%02d\n%s", t.id, t.mission);
    auto btn = new wxButton(m_mapPanel, id, label, wxDefaultPosition, wxSize(140, 60));
    btn->Bind(wxEVT_BUTTON, &StrategicLevelFrame::OnTerritory, this);
    grid->Add(btn, 0, wxEXPAND);
}
m_mapSizer->AddStretchSpacer(1);
m_mapSizer->Add(grid, 0, wxALL | wxEXPAND, 8);
m_mapPanel->SetSizer(m_mapSizer);

RefreshUI();

}



void StrategicLevelFrame::OnTool(wxCommandEvent& ev)
{
    m_mode = ev.GetId() - ID_TOOL_BASE;
    RefreshUI();
}
void StrategicLevelFrame::RefreshUI()
{

if(m_lblMoney)    m_lblMoney->SetLabel(wxString::Format("Peníze %d", m_money));
if(m_lblResearch) m_lblResearch->SetLabel(wxString::Format("Výzkum %d", m_research));
if(m_lblTurn)     m_lblTurn->SetLabel(wxString::Format("Kolo %d", m_turn));

if(m_roster)
{
    m_roster->DeleteAllItems();
    for(size_t i = 0; i < m_level.start_units.size(); ++i)
    {
        const auto& u = m_level.start_units[i];
        // TODO: later replace unit_id with localized unit name; for now show ID
        long idx = m_roster->InsertItem((long)i, wxString::Format("Jednotka %d", u.unit_id));
        m_roster->SetItem(idx, 1, wxString::Format("%d", u.count));
    }
    m_roster->SetColumnWidth(0, wxLIST_AUTOSIZE_USEHEADER);
    m_roster->SetColumnWidth(1, wxLIST_AUTOSIZE_USEHEADER);
}

if(m_btnLaunch)
    m_btnLaunch->Enable(m_selectedTerritory >= 0);

}


void StrategicLevelFrame::OnTerritory(wxCommandEvent& ev)
{
    int idx = ev.GetId() - ID_TERRITORY_BASE;
    if(idx < 0 || idx >= (int)m_level.territories.size())
        return;

    m_selectedTerritory = m_level.territories[idx].id;

    const auto& t = m_level.territories[idx];
    wxString info;
    info << wxString::Format("Territory %d\n", t.id);
    info << "Mission: " << t.mission << "\n";
    info << "Intro: " << t.intro_mission << "\n";
    info << "Music: " << t.music << "\n";
    info << wxString::Format("Strategic point: %d,%d\n", t.strategic_x, t.strategic_y);

    auto itc = m_territoryCurrentMission.find(t.id);
    if(itc != m_territoryCurrentMission.end())
        info << "Current: " << itc->second << "\n";

    auto itn = m_territoryLaunchCount.find(t.id);
    if(itn != m_territoryLaunchCount.end())
        info << wxString::Format("Played: %d\n", itn->second);

    wxMessageBox(info, "Territory", wxOK | wxICON_INFORMATION, this);
    RefreshUI();
}

void StrategicLevelFrame::OnResearch(wxCommandEvent&)
{
    if(m_money >= 100) {
        m_money -= 100;
        m_research += 1;
    } else {
        wxMessageBox("Not enough money for research (demo cost 100).", "Research", wxOK | wxICON_WARNING, this);
    }
    RefreshUI();
}

void StrategicLevelFrame::OnBuyUnits(wxCommandEvent&)
{
    wxMessageBox("Unit shop stub.\n\nSem pozdeji napojime ceny a availability podle research flagu.",
                 "Buy units", wxOK | wxICON_INFORMATION, this);
}

const LevelMission* StrategicLevelFrame::FindMissionByNameUpper(const std::string& name_upper) const
{
    for(const auto& m : m_level.missions)
    {
        if(to_upper(m.name) == name_upper)
            return &m;
    }
    return nullptr;
}

std::string StrategicLevelFrame::ResolveMissionTokenForTerritory(int territory_id) const
{
    // first play can use intro
    int launches = 0;
    auto itL = m_territoryLaunchCount.find(territory_id);
    if(itL != m_territoryLaunchCount.end()) launches = itL->second;

    // find territory record
    const LevelTerritory* terr = nullptr;
    for(const auto& t : m_level.territories)
        if(t.id == territory_id) { terr = &t; break; }

    if(!terr)
        return std::string();

    if(launches == 0 && !terr->intro_mission.empty() && terr->intro_mission != "none")
        return terr->intro_mission;

    auto it = m_territoryCurrentMission.find(territory_id);
    if(it != m_territoryCurrentMission.end() && !it->second.empty() && it->second != "none")
        return it->second;

    return terr->mission;
}

std::wstring StrategicLevelFrame::ResolveMapDefPathForMissionToken(const std::string& mission_token) const
{
    if(mission_token.empty() || mission_token == "none")
        return L"";

    namespace fs = std::filesystem;
    fs::path base = fs::path(m_level.source_path).parent_path();

    // 1) exact match (preferred)
    fs::path pExact1 = base / (to_upper(mission_token) + ".DEF");
    fs::path pExact2 = base / (mission_token + ".DEF");
    fs::path pExact3 = base / (mission_token + ".def");

    if(fs::exists(pExact1)) return pExact1.wstring();
    if(fs::exists(pExact2)) return pExact2.wstring();
    if(fs::exists(pExact3)) return pExact3.wstring();

    // 2) if token is base (e.g. m02_03) and multiple variants exist (m02_03a/b/c), offer choice
    std::string up = to_upper(mission_token);

    std::vector<fs::path> candidates;
    for(const auto& ent : fs::directory_iterator(base))
    {
        if(!ent.is_regular_file()) continue;
        auto ext = to_upper(ent.path().extension().string());
        if(ext != ".DEF") continue;

        std::string stem = to_upper(ent.path().stem().string());
        if(stem.rfind(up, 0) == 0) // starts with
            candidates.push_back(ent.path());
    }

    if(candidates.empty())
        return L"";

    if(candidates.size() == 1)
        return candidates[0].wstring();

    std::sort(candidates.begin(), candidates.end());

    wxArrayString choices;
    for(const auto& c : candidates)
        choices.Add(wxString(c.filename().wstring()));

    wxSingleChoiceDialog dlg(const_cast<StrategicLevelFrame*>(this), "Multiple mission variants found. Which one to load?", "Select mission", choices);
    if(dlg.ShowModal() != wxID_OK)
        return L"";

    int sel = dlg.GetSelection();
    if(sel < 0 || sel >= (int)candidates.size())
        return L"";

    return candidates[sel].wstring();
}

void StrategicLevelFrame::OnLaunch(wxCommandEvent&)
{
    if(m_selectedTerritory < 0 || !m_main)
        return;

    const int terr_id = m_selectedTerritory;
    std::string token = ResolveMissionTokenForTerritory(terr_id);
    if(token.empty() || token == "none")
        return;

    std::wstring defPath = ResolveMapDefPathForMissionToken(token);
    if(defPath.empty())
    {
        wxMessageBox("Map DEF not found for mission: " + wxString(token), "Launch", wxOK | wxICON_WARNING, this);
        return;
    }

    if(!m_main->LoadMapFromDefPath(defPath))
        return;

    // update launch count
    m_territoryLaunchCount[terr_id] += 1;

    // very simple progression for multi-variant missions:
    // if Mission(MXX_YYA) has EndOKMission(MXX_YYB) -> advance.
    const std::string upperName = to_upper(token);
    if(const LevelMission* m = FindMissionByNameUpper(upperName))
    {
        if(!m->end_ok_mission.empty() && m->end_ok_mission != "none")
        {
            m_territoryCurrentMission[terr_id] = to_lower(m->end_ok_mission);
        }
    }

    RefreshUI();
}

void StrategicLevelFrame::OnEndTurn(wxCommandEvent&)
{
    m_turn += 1;
    m_money += 250;
    RefreshUI();
}

static bool LoadFileBytes(const std::filesystem::path& p, std::vector<unsigned char>& out)
{
    out.clear();
    std::ifstream f(p, std::ios::binary);
    if(!f) return false;
    f.seekg(0, std::ios::end);
    std::streamsize n = f.tellg();
    f.seekg(0, std::ios::beg);
    if(n <= 0) return false;
    out.resize((size_t)n);
    return (bool)f.read((char*)out.data(), n);
}

void StrategicLevelFrame::TryLoadBackground()
{
    m_hasBg = false;
    m_bgBitmap = wxBitmap();

    namespace fs = std::filesystem;

    fs::path base = fs::path(m_level.source_path);
    base.replace_extension();

    fs::path lz = base;  lz.replace_extension(".LZ");
    fs::path pal = base; pal.replace_extension(".PAL");

    std::vector<unsigned char> lzBytes, palBytes;
    if(!LoadFileBytes(lz, lzBytes) || !LoadFileBytes(pal, palBytes))
        return;

    // Spellcross palettes are commonly 64*3 = 192 bytes
    if(palBytes.size() != 192 || lzBytes.size() < 4)
        return;

    auto rd16 = [&](size_t off) -> unsigned {
        return (unsigned)lzBytes[off] | ((unsigned)lzBytes[off + 1] << 8);
    };

    unsigned w = rd16(0);
    unsigned h = rd16(2);
    const size_t need = 4ull + (size_t)w * (size_t)h;

    // best-effort: some LZ files may not be raw (compressed). If this check fails, just skip.
    if(w == 0 || h == 0 || need > lzBytes.size())
        return;

    wxImage img((int)w, (int)h);
    unsigned char* rgb = img.GetData();
    const unsigned char* pix = lzBytes.data() + 4;

    for(unsigned y = 0; y < h; ++y)
    for(unsigned x = 0; x < w; ++x)
    {
        unsigned idx = pix[y * w + x] & 0x3F;
        unsigned char r = palBytes[idx * 3 + 0];
        unsigned char g = palBytes[idx * 3 + 1];
        unsigned char b = palBytes[idx * 3 + 2];

        size_t o = ((size_t)y * w + x) * 3;
        rgb[o + 0] = r;
        rgb[o + 1] = g;
        rgb[o + 2] = b;
    }

    m_bgBitmap = wxBitmap(img);
    m_hasBg = m_bgBitmap.IsOk();
    if(m_mapPanel) m_mapPanel->Refresh();
}

void StrategicLevelFrame::OnMapPaint(wxPaintEvent&)
{
    wxAutoBufferedPaintDC dc(m_mapPanel);
    dc.Clear();

    if(m_hasBg)
    {
        int pw, ph;
        m_mapPanel->GetClientSize(&pw, &ph);

        int bw = m_bgBitmap.GetWidth();
        int bh = m_bgBitmap.GetHeight();

        int x = (pw - bw) / 2;
        int y = (ph - bh) / 2;
        dc.DrawBitmap(m_bgBitmap, x, y, false);
    }
}
